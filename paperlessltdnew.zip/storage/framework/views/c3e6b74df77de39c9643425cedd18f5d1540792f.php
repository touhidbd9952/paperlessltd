

<?php $__env->startSection('about'); ?>

    

    <!-- ======== 2.1. hero section ========  -->
    </div>



    


    <!-- ======== 1.4. finance section ========  -->
    <section class="finance">
        <div class="container text-center">
            <h2 class="text-uppercase">Simple and Transparent Pricing</h2>
            <P class="mt-0">Paperless Limited is committed to providing cutting-edge fintech services that simplify transactions, improve financial accessibility, and empower individuals and businesses with digital payment solutions. </P>
            <div class="finanes-card row gap-md-0 gap-sm-4 gap-4">
                <div class="col-lg-4 col-md-4 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                    <div class="fin-card" data-aos="flip-up">
                        
                        
                        <style>
                            ul li{color: #E4E4E4;text-align: left;line-height: 22px;font-family: 'Poppins', sans-serif;}
                            .packagetitle{
                                
  font-weight: 700;
  line-height: 57px;
  letter-spacing: -2px;
  font-family: 'Montserrat', sans-serif;
  background: linear-gradient(-40deg, #db9b1e 0%, #C0D4C9 100%);
    background-clip: border-box;
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
                            }
                            .check{background: linear-gradient(-40deg, #db9b1e 0%, #C0D4C9 100%);background-clip: border-box;background-clip: text;-webkit-background-clip: text;-webkit-text-fill-color: transparent;}
                            .btn-hover1{padding: 5px 10px !important; width: 150px;}
                            .preq{font-weight: 900;font-size: 30px;line-height: 1.2em;color: #E4E4E4;}
                            .preqn{color: rgba(103 , 114, 148, 1); font-size: 12px;padding-bottom: 20px;}
                        </style>

                        <h4 class="packagetitle">Package 1</h4>

                        <p class="preq">
                            Call For Price <br>
                        </p> 
                        <p class="preqn"> One time fee (non-refundable)</p>  

                        <ul>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Monthly Fee
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                One Time Charge
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Visa, Mastercard, Nexus: 2.50%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Amrican Express: 3.50%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Nagad, Rocket, Bkash: 2.50%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Transaction Alert: SMS & Email
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Statement using Portal & App
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Support: Call, Email & Chat
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Dedicated Key Account Manager
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                All Payment Methods By Default
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Additional Payment Method Fee
                                </li>
                        </ul>
                        <br>
                        <a href="<?php echo e(route("contact")); ?>" class=" e-btn btn-hover1" type="submit">Contact US</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 d-flex justify-content-center pe-lg-3 pe-md-0 pe-sm-3 pe-3">
                    <div class="fin-card" data-aos="flip-up">
                        <h4 class="packagetitle">Package 2</h4>

                        <p class="preq">
                            Call For Price <br>
                        </p> 
                        <p class="preqn"> One time fee (non-refundable)</p>

                        <ul>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Monthly Fee
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                One Time Charge
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Visa, Mastercard, Nexus: 2.30%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Amrican Express: 3.30%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Nagad, Rocket, Bkash: 2.30%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Transaction Alert: SMS & Email
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Statement using Portal & App
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Support: Call, Email & Chat
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Dedicated Key Account Manager
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                All Payment Methods By Default
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Additional Payment Method Fee
                            </li>
                        </ul>
                        <br>
                        <a href="<?php echo e(route("contact")); ?>" class=" e-btn btn-hover1" type="submit">Contact US</a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 d-flex justify-content-center">
                    <div class="fin-card" data-aos="flip-up">
                        <h4 class="packagetitle">Package 3</h4>

                        <p class="preq">
                            Call For Price <br>
                        </p> 
                        <p class="preqn"> One time fee (non-refundable)</p>

                        <ul>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Monthly Fee
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                One Time Charge
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Visa, Mastercard, Nexus: 2.00%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Amrican Express: 3.15%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Nagad, Rocket, Bkash: 1.90%
                            </li>
                            <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Transaction Alert: SMS & Email
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Statement using Portal & App
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Support: Call, Email & Chat
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                Dedicated Key Account Manager
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                All Payment Methods By Default
                                </li>
                                <li class="p-f-s">
                                <span class="check">✔&nbsp;</span>
                                No Additional Payment Method Fee
                                </li>
                        </ul>
                        <br>
                        <a href="<?php echo e(route("contact")); ?>" class=" e-btn btn-hover1" type="submit">Contact US</a>
                    </div>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\paperlessltd_new\resources\views/pricing.blade.php ENDPATH**/ ?>